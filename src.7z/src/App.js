import React, { Component } from 'react';
import './App.css';
import CardList from './CardList';
// import { coinInfo } from './coinInfo';


class App extends Component {
  constructor() {
    super()
    this.state = {
      coinInfo: []
    }
  }

  componentDidMount(){

    let coinData = [];

    fetch('https://api.coinmarketcap.com/v2/ticker/')
      .then(response => response.json())
      .then(data => coinData = data.data)
      .then(coinData => {this.setState({coinInfo: coinData})});
  }

  render() {
    // const { coinInfo } = this.state;
    return (
      <div>
        <h1>Coins and Stocks</h1>
        <CardList coinInfo={ coinInfo } />
      </div>
    );
  }
}

export default App;
