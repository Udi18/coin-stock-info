import React from 'react';
import Card from './Card';

const CardList = ({ coinInfo }) => {
    const coinsIdArray = [1, 1027, 1958, 2577];

    return (
        <div className="container-fluid row">
            <Card name={coinInfo[coinsIdArray[0]].name} rank={coinInfo[coinsIdArray[0]].rank} price={coinInfo[coinsIdArray[0]].quotes["USD"].price} percentChange24={coinInfo[coinsIdArray[0]].quotes["USD"].percent_change_24h} />
            <Card name={coinInfo[coinsIdArray[1]].name} rank={coinInfo[coinsIdArray[1]].rank} price={coinInfo[coinsIdArray[1]].quotes["USD"].price} percentChange24={coinInfo[coinsIdArray[1]].quotes["USD"].percent_change_24h} />
            <Card name={coinInfo[coinsIdArray[2]].name} rank={coinInfo[coinsIdArray[2]].rank} price={coinInfo[coinsIdArray[2]].quotes["USD"].price} percentChange24={coinInfo[coinsIdArray[2]].quotes["USD"].percent_change_24h} />
            <Card name={coinInfo[coinsIdArray[3]].name} rank={coinInfo[coinsIdArray[3]].rank} price={coinInfo[coinsIdArray[3]].quotes["USD"].price} percentChange24={coinInfo[coinsIdArray[3]].quotes["USD"].percent_change_24h} />
        </div>
    )
}

export default CardList;